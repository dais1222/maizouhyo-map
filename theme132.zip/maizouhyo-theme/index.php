<?php get_header(); ?>
<main class="unit-main" style="margin-top:0;padding-top:60px">
  <div class="wrap" style="max-width:860px">
    <?php if (is_archive() || is_home()) : ?>
      <div class="sec-k" style="margin-bottom:6px">WEEKLY ANALYSIS</div>
      <h1 style="font-size:24px;font-weight:800;color:var(--navy);margin-bottom:26px">埋蔵票分析コラム</h1>
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article class="card">
          <p style="font-size:12px;color:var(--ink-3);font-weight:700"><?php echo get_the_date('Y年n月j日'); ?></p>
          <h2 style="margin:6px 0 10px"><a href="<?php the_permalink(); ?>" style="color:var(--navy)"><?php the_title(); ?></a></h2>
          <p style="font-size:14px;color:var(--ink-2)"><?php echo esc_html(get_the_excerpt()); ?></p>
          <p style="margin-top:12px"><a class="btn btn-ghost" href="<?php the_permalink(); ?>">続きを読む</a></p>
        </article>
      <?php endwhile; the_posts_pagination(); else : ?>
        <div class="card"><p>記事はまだありません。</p></div>
      <?php endif; ?>
    <?php else : ?>
    <div class="card">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php if (is_single()) : ?><p style="font-size:12px;color:var(--ink-3);font-weight:700"><?php echo get_the_date('Y年n月j日'); ?>｜埋蔵票分析コラム</p><?php endif; ?>
        <h1 style="font-size:22px;font-weight:800;color:var(--navy);line-height:1.6;margin:6px 0 18px"><?php the_title(); ?></h1>
        <div style="font-size:15px;line-height:2"><?php the_content(); ?></div>
      <?php endwhile; else : ?>
        <h2>ページが見つかりません</h2>
        <p><a href="<?php echo esc_url(home_url('/')); ?>">トップページへ戻る</a></p>
      <?php endif; ?>
    </div>
    <?php if (is_single()) : ?>
    <div class="cta-card">
      <h2>あなたの街の埋蔵票も、無料で確認できます。</h2>
      <p>会員登録すると、出馬予定の自治体の埋蔵票・当選ライン・政党別分析がすべて見られます。</p>
      <a class="btn btn-cta" style="background:#fff;color:var(--pink-dark)" href="<?php echo esc_url(home_url('/register/')); ?>">無料会員登録する</a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
  </div>
</main>
<?php get_footer(); ?>
