<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/favicon-32.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/favicon-180.png">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="wrap hd">
    <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">埋蔵票マップ<small>MOPPs ANALYSIS</small></a>
    <nav class="gnav">
      <a href="<?php echo esc_url(home_url('/#about')); ?>">埋蔵票とは</a>
      <a href="<?php echo esc_url(home_url('/#data')); ?>">分析データ</a>
      <a href="<?php echo esc_url(home_url('/#members')); ?>">会員でできること</a>
      <a href="<?php echo esc_url(home_url('/category/weekly-analysis/')); ?>">分析コラム</a>
      <a href="<?php echo esc_url(home_url('/#company')); ?>">運営会社</a>
    </nav>
    <span style="margin-left:auto"></span>
    <?php if (is_user_logged_in()) : $mu = mz_unit(mz_user_unit()); ?>
      <?php if ($mu) : ?><a class="btn btn-ghost" href="<?php echo esc_url(home_url('/a/' . mz_user_unit() . '/')); ?>"><?php echo esc_html($mu['name']); ?>の分析</a><?php endif; ?>
      <a class="btn btn-ghost" href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>">ログアウト</a>
    <?php else : ?>
      <a class="btn btn-ghost" href="<?php echo esc_url(wp_login_url()); ?>">ログイン</a>
      <a class="btn btn-cta" href="<?php echo esc_url(home_url('/register/')); ?>">無料会員登録</a>
    <?php endif; ?>
  </div>
</header>
