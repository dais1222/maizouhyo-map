<?php
/**
 * 埋蔵票マップ テーマ機能
 * - データ読込（wp-content/uploads/maizouhyo/data/）
 * - /a/{id}/ の自治体ページ（rewrite）
 * - 会員登録（氏名・住所・メール・電話・自治体）→ パスワードはWP標準のメールリンクで本人が設定
 * - 会員は自分の登録自治体のみ専門分析（レポート表示）を閲覧可
 * - 週次データ更新用REST（トークン認証）
 */
if (!defined('ABSPATH')) exit;

/* ---------- 基本 ---------- */
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    remove_action('wp_head', 'wp_generator');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('mz-style', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});

/* ---------- データ ---------- */
function mz_data_dir() {
    $u = wp_upload_dir();
    return trailingslashit($u['basedir']) . 'maizouhyo/data/';
}
function mz_data_url_protect() { /* データ直リンクを禁止する .htaccess を自動設置 */
    $dir = mz_data_dir();
    if (is_dir($dir) && !file_exists($dir . '.htaccess')) {
        @file_put_contents($dir . '.htaccess', "Require all denied\n");
    }
}
add_action('admin_init', 'mz_data_url_protect');

function mz_index() {
    static $idx = null;
    if ($idx === null) {
        $f = mz_data_dir() . 'index.json';
        $idx = file_exists($f) ? json_decode(file_get_contents($f), true) : ['units' => []];
    }
    return $idx;
}
function mz_unit($id) {
    if (!preg_match('/^[cwp]\d{1,7}$/', $id)) return null;
    $f = mz_data_dir() . 'units/' . $id . '.json';
    return file_exists($f) ? json_decode(file_get_contents($f), true) : null;
}
function mz_index_slim_json() { /* 検索用の軽量インデックス（公開情報のみ） */
    $rows = [];
    foreach (mz_index()['units'] as $u) {
        $rows[] = [$u['id'], $u['pref'], $u['name'], $u['sub'], $u['rank']];
    }
    return wp_json_encode($rows, JSON_UNESCAPED_UNICODE);
}

/* ---------- 自治体ページ /a/{id}/ ---------- */
add_action('init', function () {
    add_rewrite_rule('^a/([cwp][0-9]+)/?$', 'index.php?mz_unit=$matches[1]', 'top');
});
add_filter('query_vars', function ($v) { $v[] = 'mz_unit'; return $v; });
add_action('template_redirect', function () {
    $id = get_query_var('mz_unit');
    if ($id) {
        status_header(200);
        include get_template_directory() . '/unit.php';
        exit;
    }
});
/* テーマ有効化時の初期設定（パーマリンク・固定ページ・データ受信トークン） */
add_action('after_switch_theme', function () {
    if (!get_option('permalink_structure')) update_option('permalink_structure', '/%postname%/');
    update_option('blogdescription', 'あなたの街の「掘り起こされていない票」を見える化');
    if (!get_option('mz_push_token')) update_option('mz_push_token', bin2hex(random_bytes(24)));
    $pages = [
        ['title' => '無料会員登録', 'slug' => 'register', 'tpl' => 'page-register.php'],
        ['title' => 'プライバシーポリシー', 'slug' => 'privacy', 'tpl' => ''],
        ['title' => '特定商取引法に基づく表記', 'slug' => 'tokushoho', 'tpl' => ''],
    ];
    foreach ($pages as $p) {
        if (!get_page_by_path($p['slug'])) {
            $pid = wp_insert_post(['post_title' => $p['title'], 'post_name' => $p['slug'],
                'post_type' => 'page', 'post_status' => 'publish', 'post_content' => $p['tpl'] ? '' : '準備中です。']);
            if ($p['tpl'] && !is_wp_error($pid)) update_post_meta($pid, '_wp_page_template', $p['tpl']);
        }
    }
    wp_mkdir_p(mz_data_dir() . 'units');
    mz_data_url_protect();
    flush_rewrite_rules(true);
});
/* データ受信トークンを管理者にだけ表示（データ投入設定用） */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    $t = get_option('mz_push_token');
    $has = file_exists(mz_data_dir() . 'index.json');
    if ($t && !$has) {
        echo '<div class="notice notice-info"><p><b>埋蔵票マップ データ受信トークン:</b> <code id="mz-token">' . esc_html($t) . '</code>（分析データ投入時に使用します。データ投入後この表示は消えます）</p></div>';
    }
});

/* ---------- 会員 ---------- */
function mz_user_unit($user_id = 0) {
    $user_id = $user_id ?: get_current_user_id();
    return $user_id ? get_user_meta($user_id, 'mz_unit', true) : '';
}
function mz_can_view($id) {
    return is_user_logged_in() && (mz_user_unit() === $id || current_user_can('manage_options'));
}

/* 登録フォーム処理（page-register.php から） */
function mz_handle_register() {
    if (!isset($_POST['mz_reg_nonce']) || !wp_verify_nonce($_POST['mz_reg_nonce'], 'mz_register')) return null;
    $name  = sanitize_text_field($_POST['mz_name'] ?? '');
    $addr  = sanitize_text_field($_POST['mz_address'] ?? '');
    $mail  = sanitize_email($_POST['mz_email'] ?? '');
    $tel   = sanitize_text_field($_POST['mz_phone'] ?? '');
    $unit  = sanitize_text_field($_POST['mz_unit'] ?? '');
    if (!$name || !$addr || !$mail || !$tel || !$unit) return ['err' => '未入力の項目があります。すべての項目をご入力ください。'];
    if (!is_email($mail)) return ['err' => 'メールアドレスの形式が正しくありません。'];
    if (!mz_unit($unit)) return ['err' => '自治体の選択が正しくありません。候補から選択してください。'];
    if (email_exists($mail)) return ['err' => 'このメールアドレスは登録済みです。ログインするか、パスワード再設定をご利用ください。'];
    $uid = wp_insert_user([
        'user_login'   => $mail,
        'user_email'   => $mail,
        'user_pass'    => wp_generate_password(24), // 仮。本人がメールのリンクで設定し直す
        'display_name' => $name,
        'role'         => 'subscriber',
    ]);
    if (is_wp_error($uid)) return ['err' => '登録に失敗しました: ' . esc_html($uid->get_error_message())];
    update_user_meta($uid, 'mz_name', $name);
    update_user_meta($uid, 'mz_address', $addr);
    update_user_meta($uid, 'mz_phone', $tel);
    update_user_meta($uid, 'mz_unit', $unit);
    wp_new_user_notification($uid, null, 'both'); // 本人にパスワード設定リンク＋管理者に通知
    return ['ok' => true, 'unit' => $unit];
}

/* 管理画面: 会員一覧に登録情報列を表示 */
add_filter('manage_users_columns', function ($c) {
    $c['mz_unit'] = '登録自治体'; $c['mz_phone'] = '電話'; $c['mz_address'] = '住所';
    return $c;
});
add_filter('manage_users_custom_column', function ($val, $col, $uid) {
    if ($col === 'mz_unit') {
        $u = mz_unit(get_user_meta($uid, 'mz_unit', true));
        return $u ? esc_html($u['pref'] . $u['name'] . '（' . $u['sub'] . '）') : '—';
    }
    if ($col === 'mz_phone') return esc_html(get_user_meta($uid, 'mz_phone', true));
    if ($col === 'mz_address') return esc_html(get_user_meta($uid, 'mz_address', true));
    return $val;
}, 10, 3);

/* 会員はログイン後に自分の自治体ページへ、管理者はダッシュボードへ */
add_filter('login_redirect', function ($to, $req, $user) {
    if ($user instanceof WP_User && !user_can($user, 'manage_options')) {
        $unit = mz_user_unit($user->ID);
        if ($unit) return home_url('/a/' . $unit . '/');
        return home_url('/');
    }
    return $to;
}, 10, 3);
/* 一般会員には管理バーを出さない */
add_filter('show_admin_bar', function ($show) {
    return current_user_can('manage_options') ? $show : false;
});


/* ============ SEO（2026-10-08 追加） ============
   問題: 自治体ページ2,971件がサイトマップにも内部リンクにも存在せず、
   かつ全ページが同一タイトル（トップと同じ）だったためインデックスされていなかった。 */

function mz_current_area() {
    $a = get_query_var('mz_area');
    if (!$a) return '';
    return ($a === 'all') ? 'all' : urldecode($a);
}

function mz_current_unit() {
    static $u = null, $done = false;
    if ($done) return $u;
    $done = true;
    $id = get_query_var('mz_unit');
    if ($id) $u = mz_unit($id);
    return $u;
}

/* タイトル（自治体ページ・エリア一覧） */
add_filter('document_title_parts', function ($parts) {
    if ($u = mz_current_unit()) {
        $parts['title'] = $u['pref'] . $u['name'] . 'の' . $u['sub'] . '分析｜当選ライン・埋蔵票';
        unset($parts['tagline']);
        $parts['site'] = '埋蔵票マップ';
    } elseif ($p = mz_current_area()) {
        $parts['title'] = ($p === 'all') ? '全国の自治体一覧（市区町村・政令市区・都道府県議選挙区）'
                                         : $p . 'の自治体一覧｜当選ライン・埋蔵票';
        unset($parts['tagline']);
        $parts['site'] = '埋蔵票マップ';
    }
    return $parts;
});

/* メタディスクリプション・正規URL・OGP・構造化データ */
add_action('wp_head', function () {
    $site = home_url('/');
    $desc = $url = $title = '';
    if ($u = mz_current_unit()) {
        $url = home_url('/a/' . $u['id'] . '/');
        $title = $u['pref'] . $u['name'] . 'の' . $u['sub'] . '分析';
        $d = $u['date'] ? date_i18n('Y年n月j日', strtotime($u['date'])) : '';
        $desc = sprintf('%s%sの%s（%s執行）の分析。定数%s、候補者%s人、当選ラインは%s票でした。埋蔵票ランク%s。出馬を検討する方向けに、当選に必要な票数・政党別の上積み余地・現職の次回予測を公開しています。',
            $u['pref'], $u['name'], $u['sub'], $d, $u['seats'], $u['n_cands'],
            number_format((float)$u['line']), $u['rank']);
    } elseif ($p = mz_current_area()) {
        $url = home_url($p === 'all' ? '/areas/' : '/areas/' . rawurlencode($p) . '/');
        $title = ($p === 'all') ? '全国の自治体一覧' : $p . 'の自治体一覧';
        $desc = ($p === 'all')
            ? '全国1,741市区町村・政令市169区・都道府県議会1,082選挙区の選挙分析ページ一覧です。各自治体の当選ライン・候補者数・埋蔵票ランクを確認できます。'
            : $p . 'の市区町村・選挙区の選挙分析ページ一覧です。各自治体の当選ライン・候補者数・埋蔵票ランクを確認できます。';
    } elseif (is_singular('post')) {
        $url = get_permalink();
        $title = get_the_title();
        $desc = get_the_excerpt();
    } elseif (is_front_page()) {
        $url = $site;
        $title = '埋蔵票マップ｜全国の選挙を分析し「眠っている票」を見える化';
        $desc = '全国1,741市区町村の地方選挙を統計分析。当選ライン・候補者数・埋蔵票（既存政党や現職に固定されていない票）を自治体ごとに公開しています。出馬を検討する方の最初の戦略資料に。';
    }
    if (!$desc) return;
    $desc = mb_substr(trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($desc))), 0, 140);
    echo "\n" . '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
    if ($url) echo '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
    if ($url) echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:site_name" content="埋蔵票マップ">' . "\n";
    echo '<meta name="twitter:card" content="summary">' . "\n";

    /* パンくずの構造化データ */
    $crumbs = [['name' => '埋蔵票マップ', 'item' => $site]];
    if ($u = mz_current_unit()) {
        $crumbs[] = ['name' => $u['pref'], 'item' => home_url('/areas/' . rawurlencode($u['pref']) . '/')];
        $crumbs[] = ['name' => $u['name'], 'item' => $url];
    } elseif ($p = mz_current_area()) {
        $crumbs[] = ['name' => '自治体一覧', 'item' => home_url('/areas/')];
        if ($p !== 'all') $crumbs[] = ['name' => $p, 'item' => $url];
    } elseif (is_singular('post')) {
        $crumbs[] = ['name' => '選挙分析', 'item' => home_url('/category/weekly-analysis/')];
        $crumbs[] = ['name' => get_the_title(), 'item' => $url];
    }
    if (count($crumbs) > 1) {
        $items = [];
        foreach ($crumbs as $i => $c) {
            $items[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $c['name'], 'item' => $c['item']];
        }
        echo '<script type="application/ld+json">' . wp_json_encode(
            ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
    if (is_singular('post')) {
        echo '<script type="application/ld+json">' . wp_json_encode([
            '@context' => 'https://schema.org', '@type' => 'Article',
            'headline' => mb_substr(get_the_title(), 0, 110),
            'datePublished' => get_the_date('c'), 'dateModified' => get_the_modified_date('c'),
            'author' => ['@type' => 'Organization', 'name' => '株式会社MOPPs'],
            'publisher' => ['@type' => 'Organization', 'name' => '埋蔵票マップ'],
            'mainEntityOfPage' => $url,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
}, 1);

/* 自治体ページ用サイトマップ（WP本体のサイトマップは投稿しか拾わないため自前で出力） */
add_action('init', function () {
    add_rewrite_rule('^mz-sitemap\.xml$', 'index.php?mz_sitemap=index', 'top');
    add_rewrite_rule('^mz-sitemap-areas\.xml$', 'index.php?mz_sitemap=areas', 'top');
    add_rewrite_rule('^mz-sitemap-([0-9]+)\.xml$', 'index.php?mz_sitemap=$matches[1]', 'top');
    add_rewrite_rule('^areas/?$', 'index.php?mz_area=all', 'top');
    add_rewrite_rule('^areas/([^/]+)/?$', 'index.php?mz_area=$matches[1]', 'top');
});
add_filter('query_vars', function ($v) { $v[] = 'mz_sitemap'; $v[] = 'mz_area'; return $v; });

define('MZ_SITEMAP_CHUNK', 1000);

add_action('template_redirect', function () {
    $sm = get_query_var('mz_sitemap');
    if ($sm === '' || $sm === null) return;
    $units = mz_index()['units'];
    $total = (int) ceil(count($units) / MZ_SITEMAP_CHUNK);
    header('Content-Type: application/xml; charset=UTF-8');
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    if ($sm === 'index') {
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        for ($i = 1; $i <= $total; $i++) {
            echo '<sitemap><loc>' . esc_url(home_url('/mz-sitemap-' . $i . '.xml')) . '</loc></sitemap>' . "\n";
        }
        echo '<sitemap><loc>' . esc_url(home_url('/mz-sitemap-areas.xml')) . '</loc></sitemap>' . "\n";
        echo '</sitemapindex>';
        exit;
    }
    if ($sm === 'areas') {
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        echo '<url><loc>' . esc_url(home_url('/areas/')) . '</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>' . "\n";
        foreach (array_keys(mz_units_by_pref()) as $pf) {
            echo '<url><loc>' . esc_url(home_url('/areas/' . rawurlencode($pf) . '/')) . '</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>' . "\n";
        }
        echo '</urlset>';
        exit;
    }
    $page = max(1, (int) $sm);
    $slice = array_slice($units, ($page - 1) * MZ_SITEMAP_CHUNK, MZ_SITEMAP_CHUNK);
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach ($slice as $u) {
        echo '<url><loc>' . esc_url(home_url('/a/' . $u['id'] . '/')) . '</loc>'
           . (!empty($u['date']) ? '<lastmod>' . esc_html($u['date']) . '</lastmod>' : '')
           . '<changefreq>monthly</changefreq><priority>0.6</priority></url>' . "\n";
    }
    echo '</urlset>';
    exit;
}, 0);

/* エリア一覧ページ */
add_action('template_redirect', function () {
    if (get_query_var('mz_area')) {
        status_header(200);
        include get_template_directory() . '/areas.php';
        exit;
    }
});

/* robots.txt に自前サイトマップを追記 */
add_filter('robots_txt', function ($out) {
    return $out . "\nSitemap: " . home_url('/mz-sitemap.xml') . "\n";
}, 10, 1);

/* 都道府県 → 自治体一覧（キャッシュ付き） */
function mz_units_by_pref($pref = null) {
    static $map = null;
    if ($map === null) {
        $map = [];
        foreach (mz_index()['units'] as $u) {
            $map[$u['pref']][] = $u;
        }
    }
    if ($pref === null) return $map;
    return $map[$pref] ?? [];
}

/* テーマ更新時にURLルールを反映（新しいルールを追加したときに必要） */
add_action('init', function () {
    $v = wp_get_theme()->get('Version');
    if (get_option('mz_theme_version') !== $v) {
        update_option('mz_theme_version', $v);
        flush_rewrite_rules(false);
    }
}, 99);

/* ---------- 週次分析記事の受信 REST（GitHub Actions 用・トークン認証） ---------- */
add_action('rest_api_init', function () {
    register_rest_route('maizouhyo/v1', '/article', [
        'methods'  => 'POST',
        'permission_callback' => function ($req) {
            $t = get_option('mz_push_token');
            return $t && hash_equals($t, (string)$req->get_header('x-mz-token'));
        },
        'callback' => function ($req) {
            $p = $req->get_json_params();
            if (empty($p['title']) || empty($p['content'])) {
                return new WP_Error('bad_request', 'title/content required', ['status' => 400]);
            }
            $cat = get_category_by_slug('weekly-analysis');
            if (!$cat) {
                $cid = wp_insert_term('埋蔵票分析', 'category', ['slug' => 'weekly-analysis']);
                $cat_id = is_wp_error($cid) ? 0 : $cid['term_id'];
            } else { $cat_id = $cat->term_id; }
            $slug = sanitize_title($p['slug'] ?? '');
            $existing = $slug ? get_page_by_path($slug, OBJECT, 'post') : null;
            $post = [
                'post_title'    => sanitize_text_field($p['title']),
                'post_content'  => wp_kses_post($p['content']),
                'post_excerpt'  => sanitize_text_field($p['excerpt'] ?? ''),
                'post_status'   => 'publish',
                'post_type'     => 'post',
                'post_name'     => $slug,
                'post_category' => $cat_id ? [$cat_id] : [],
            ];
            if ($existing) { $post['ID'] = $existing->ID; $pid = wp_update_post($post, true); }
            else { $pid = wp_insert_post($post, true); }
            if (is_wp_error($pid)) return new WP_Error('save_failed', $pid->get_error_message(), ['status' => 500]);
            return ['id' => $pid, 'link' => get_permalink($pid), 'updated' => (bool)$existing];
        },
    ]);
});

/* ---------- 週次データ更新 REST（GitHub Actions 用） ---------- */
add_action('rest_api_init', function () {
    register_rest_route('maizouhyo/v1', '/push', [
        'methods'  => 'POST',
        'permission_callback' => function ($req) {
            $t = get_option('mz_push_token');
            return $t && hash_equals($t, (string)$req->get_header('x-mz-token'));
        },
        'callback' => function ($req) {
            $p = $req->get_json_params();
            /* 単発 {file,json} または一括 {files:[{file,json},...]} */
            $items = isset($p['files']) && is_array($p['files']) ? $p['files']
                   : ((!empty($p['file']) && isset($p['json'])) ? [$p] : null);
            if ($items === null) return new WP_Error('bad_request', 'file/json or files[] required', ['status' => 400]);
            $dir = mz_data_dir();
            wp_mkdir_p($dir . 'units');
            mz_data_url_protect();
            $saved = 0; $bad = [];
            foreach ($items as $it) {
                $file = $it['file'] ?? '';
                if (!preg_match('#^(index\.json|units/[cwp]\d{1,7}\.json)$#', $file) || !isset($it['json'])) { $bad[] = $file; continue; }
                if (file_put_contents($dir . $file, wp_json_encode($it['json'], JSON_UNESCAPED_UNICODE))) $saved++;
            }
            return ['saved' => $saved, 'bad' => $bad];
        },
    ]);
});
