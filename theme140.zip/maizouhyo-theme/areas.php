<?php
/* 自治体一覧 /areas/ ・ /areas/{都道府県}/ （クロール導線とユーザーの回遊用） */
$area = get_query_var('mz_area');
$map  = mz_units_by_pref();
$PREF_ORDER = ['北海道','青森県','岩手県','宮城県','秋田県','山形県','福島県','茨城県','栃木県','群馬県','埼玉県','千葉県','東京都','神奈川県','新潟県','富山県','石川県','福井県','山梨県','長野県','岐阜県','静岡県','愛知県','三重県','滋賀県','京都府','大阪府','兵庫県','奈良県','和歌山県','鳥取県','島根県','岡山県','広島県','山口県','徳島県','香川県','愛媛県','高知県','福岡県','佐賀県','長崎県','熊本県','大分県','宮崎県','鹿児島県','沖縄県'];
$is_all = ($area === 'all');
if (!$is_all && !isset($map[$area])) {
    global $wp_query; $wp_query->set_404(); status_header(404);
    get_header(); echo '<div class="wrap" style="padding:80px 20px"><h1>ページが見つかりません</h1><p><a href="'.esc_url(home_url('/areas/')).'">自治体一覧へ</a></p></div>'; get_footer(); exit;
}
get_header(); ?>

<div class="pagehead">
  <div class="wrap">
    <div class="crumbs"><a href="<?php echo esc_url(home_url('/')); ?>">埋蔵票マップ</a> ＞ <?php
      echo $is_all ? '自治体一覧' : '<a href="'.esc_url(home_url('/areas/')).'" style="color:#fff;text-decoration:underline">自治体一覧</a> ＞ '.esc_html($area); ?></div>
    <h1><?php echo $is_all ? '全国の自治体一覧' : esc_html($area).'の自治体一覧'; ?></h1>
    <div class="meta"><span><?php echo $is_all ? '市区町村・政令市の区・都道府県議会の選挙区をすべて掲載しています' : esc_html($area).'の市区町村・選挙区の分析ページ'; ?></span></div>
  </div>
</div>

<main class="unit-main">
  <div class="wrap">
  <?php if ($is_all) : ?>
    <div class="card">
      <h2>都道府県から選ぶ</h2>
      <div class="pref-grid">
        <?php foreach ($PREF_ORDER as $p) : if (empty($map[$p])) continue; ?>
          <a class="pref-item" href="<?php echo esc_url(home_url('/areas/'.rawurlencode($p).'/')); ?>">
            <span class="n"><?php echo esc_html($p); ?></span><span class="c"><?php echo count($map[$p]); ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  <?php else : $list = $map[$area];
    usort($list, function($a,$b){ return [$a['kind'],$a['name']] <=> [$b['kind'],$b['name']]; });
    $groups = ['city'=>'市区町村','town'=>'町村','ward'=>'政令市の区','pref'=>'都道府県議会の選挙区'];
    foreach ($groups as $k => $label):
      $rows = array_values(array_filter($list, function($u) use ($k){ return $u['kind'] === $k; }));
      if (!$rows) continue; ?>
    <div class="card">
      <h2><?php echo esc_html($label); ?><span class="badge" style="background:var(--bg-soft);color:var(--ink-2)"><?php echo count($rows); ?>件</span></h2>
      <div class="muni-grid">
        <?php foreach ($rows as $u) : ?>
          <a class="muni-item" href="<?php echo esc_url(home_url('/a/'.$u['id'].'/')); ?>">
            <span class="rank-pill r<?php echo esc_attr($u['rank']); ?>"><?php echo esc_html($u['rank']); ?></span>
            <span class="nm"><?php echo esc_html($u['name']); ?></span>
          </a>
        <?php endforeach; ?>
      </div>
      <p class="wa-note">※ 丸い記号は埋蔵票ランク（S＝最も多い〜D）です。</p>
    </div>
    <?php endforeach; ?>
    <div class="card">
      <h2>ほかの都道府県</h2>
      <div class="pref-grid">
        <?php foreach ($PREF_ORDER as $p) : if (empty($map[$p]) || $p === $area) continue; ?>
          <a class="pref-item" href="<?php echo esc_url(home_url('/areas/'.rawurlencode($p).'/')); ?>"><span class="n"><?php echo esc_html($p); ?></span><span class="c"><?php echo count($map[$p]); ?></span></a>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

    <div class="cta-card">
      <h2 style="color:#fff;font-size:20px;font-weight:800;margin-bottom:10px;display:flex;justify-content:center">あなたの街の埋蔵票を、無料で確認できます。</h2>
      <p style="color:var(--pink-soft);font-size:14px;margin-bottom:20px">無料会員に登録すると、出馬を予定する自治体の埋蔵票・当選ライン・政党別の上積み余地・現職の次回予測がすべて見られます。</p>
      <a class="btn btn-cta" style="background:#fff;color:var(--pink-dark);padding:14px 34px" href="<?php echo esc_url(home_url('/register/')); ?>">無料で会員登録する</a>
    </div>
  </div>
</main>
<?php get_footer(); ?>
