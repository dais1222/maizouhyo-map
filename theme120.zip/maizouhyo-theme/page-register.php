<?php
/* Template Name: 会員登録
   固定ページ（スラッグ: register）に割り当てて使用 */
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') $result = mz_handle_register();
$preset = sanitize_text_field($_GET['unit'] ?? '');
$preset_u = $preset ? mz_unit($preset) : null;
get_header(); ?>

<div class="pagehead">
  <div class="wrap">
    <div class="crumbs">埋蔵票マップ ＞ 無料会員登録</div>
    <h1>無料会員登録</h1>
    <div class="meta"><span>登録すると、出馬予定の自治体の専門分析レポートが見られるようになります。</span></div>
  </div>
</div>

<main class="unit-main">
  <div class="wrap form-card">
    <div class="card" style="margin-top:22px">

    <?php if ($result && !empty($result['ok'])) : ?>
      <div class="form-msg ok">✅ 登録を受け付けました。<br>ご入力のメールアドレス宛に<b>パスワード設定用のリンク</b>をお送りしました。メール内のリンクからパスワードを設定し、ログインしてください。（メールが届かない場合は迷惑メールフォルダをご確認ください）</div>
      <a class="btn btn-cta" href="<?php echo esc_url(wp_login_url(home_url('/a/' . $result['unit'] . '/'))); ?>">ログインページへ</a>
    <?php else : ?>

      <?php if ($result && !empty($result['err'])) : ?>
        <div class="form-msg err">⚠️ <?php echo esc_html($result['err']); ?></div>
      <?php endif; ?>

      <form method="post">
        <?php wp_nonce_field('mz_register', 'mz_reg_nonce'); ?>
        <label>氏名<span class="req">必須</span></label>
        <input type="text" name="mz_name" required value="<?php echo esc_attr($_POST['mz_name'] ?? ''); ?>" placeholder="例）選挙 太郎">
        <label>住所<span class="req">必須</span></label>
        <input type="text" name="mz_address" required value="<?php echo esc_attr($_POST['mz_address'] ?? ''); ?>" placeholder="例）埼玉県新座市○○1-2-3">
        <label>メールアドレス<span class="req">必須</span>（ログインIDになります）</label>
        <input type="email" name="mz_email" required value="<?php echo esc_attr($_POST['mz_email'] ?? ''); ?>" placeholder="例）taro@example.com">
        <label>電話番号<span class="req">必須</span></label>
        <input type="tel" name="mz_phone" required value="<?php echo esc_attr($_POST['mz_phone'] ?? ''); ?>" placeholder="例）090-1234-5678">
        <label>立候補を検討している自治体（現職の方はいまの自治体）<span class="req">必須</span></label>
        <div class="unit-pick">
          <input type="text" id="mzUnitSearch" autocomplete="off" required
                 value="<?php echo $preset_u ? esc_attr($preset_u['pref'] . $preset_u['name'] . '（' . $preset_u['sub'] . '）') : ''; ?>"
                 placeholder="自治体名を入力して候補から選択">
          <input type="hidden" name="mz_unit" id="mzUnitId" value="<?php echo esc_attr($preset_u ? $preset : ''); ?>">
          <div class="hits" id="mzUnitHits" style="display:none"></div>
        </div>
        <p style="font-size:12px;color:var(--ink-3);margin-top:8px">※ 専門分析はご登録いただいた自治体のみ閲覧できます。変更は運営までご連絡ください。</p>
        <button type="submit" class="btn btn-cta send">この内容で登録する（無料）</button>
        <p style="font-size:11.5px;color:var(--ink-3);margin-top:12px">ご入力いただいた情報は、本サービスの提供およびご連絡のために利用し、<a href="<?php echo esc_url(home_url('/privacy/')); ?>" style="text-decoration:underline">プライバシーポリシー</a>に基づいて管理します。</p>
      </form>

      <script>
      const MZ_UNITS = <?php echo mz_index_slim_json(); ?>;
      const ui = document.getElementById('mzUnitSearch'), uh = document.getElementById('mzUnitHits'), uid = document.getElementById('mzUnitId');
      ui.addEventListener('input', () => {
        uid.value = '';
        const q = ui.value.trim().normalize('NFKC');
        if (q.length < 1) { uh.style.display = 'none'; return; }
        const m = MZ_UNITS.filter(u => (u[1] + u[2]).includes(q) || u[2].includes(q)).slice(0, 12);
        uh.innerHTML = m.map(u => `<div data-id="${u[0]}">${u[1]} <b>${u[2]}</b> <span style="font-size:11px;color:#8a93a8">${u[3]}</span></div>`).join('') || '<div>該当なし</div>';
        uh.style.display = 'block';
        uh.querySelectorAll('div[data-id]').forEach(el => el.addEventListener('click', () => {
          uid.value = el.dataset.id; ui.value = el.textContent.trim(); uh.style.display = 'none';
        }));
      });
      document.addEventListener('click', e => { if (!e.target.closest('.unit-pick')) uh.style.display = 'none'; });
      </script>

    <?php endif; ?>
    </div>
  </div>
</main>

<?php get_footer(); ?>
