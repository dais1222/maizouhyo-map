<footer class="site-footer">
  <div class="wrap">
    <p>© 株式会社MOPPs ｜ <a href="https://senkyo.mopps.co.jp/" target="_blank" rel="noopener">0円選挙.com</a> ｜ <a href="<?php echo esc_url(home_url('/tokushoho/')); ?>">特定商取引法に基づく表記</a> ｜ <a href="<?php echo esc_url(home_url('/privacy/')); ?>">プライバシーポリシー</a></p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
