<?php get_header(); ?>
<main class="unit-main" style="margin-top:0;padding-top:60px">
  <div class="wrap">
    <div class="card">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <h2><?php the_title(); ?></h2>
        <div><?php the_content(); ?></div>
      <?php endwhile; else : ?>
        <h2>ページが見つかりません</h2>
        <p><a href="<?php echo esc_url(home_url('/')); ?>">トップページへ戻る</a></p>
      <?php endif; ?>
    </div>
  </div>
</main>
<?php get_footer(); ?>
