<?php
/**
 * 埋蔵票マップ テーマ機能
 * - データ読込（wp-content/uploads/maizouhyo/data/）
 * - /a/{id}/ の自治体ページ（rewrite）
 * - 会員登録（氏名・住所・メール・電話・自治体）→ パスワードはWP標準のメールリンクで本人が設定
 * - 会員は自分の登録自治体のみ専門分析（レポート表示）を閲覧可
 * - 週次データ更新用REST（トークン認証）
 */
if (!defined('ABSPATH')) exit;

/* ---------- 基本 ---------- */
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    remove_action('wp_head', 'wp_generator');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('mz-style', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});

/* ---------- データ ---------- */
function mz_data_dir() {
    $u = wp_upload_dir();
    return trailingslashit($u['basedir']) . 'maizouhyo/data/';
}
function mz_data_url_protect() { /* データ直リンクを禁止する .htaccess を自動設置 */
    $dir = mz_data_dir();
    if (is_dir($dir) && !file_exists($dir . '.htaccess')) {
        @file_put_contents($dir . '.htaccess', "Require all denied\n");
    }
}
add_action('admin_init', 'mz_data_url_protect');

function mz_index() {
    static $idx = null;
    if ($idx === null) {
        $f = mz_data_dir() . 'index.json';
        $idx = file_exists($f) ? json_decode(file_get_contents($f), true) : ['units' => []];
    }
    return $idx;
}
function mz_unit($id) {
    if (!preg_match('/^[cwp]\d{1,7}$/', $id)) return null;
    $f = mz_data_dir() . 'units/' . $id . '.json';
    return file_exists($f) ? json_decode(file_get_contents($f), true) : null;
}
function mz_index_slim_json() { /* 検索用の軽量インデックス（公開情報のみ） */
    $rows = [];
    foreach (mz_index()['units'] as $u) {
        $rows[] = [$u['id'], $u['pref'], $u['name'], $u['sub'], $u['rank']];
    }
    return wp_json_encode($rows, JSON_UNESCAPED_UNICODE);
}

/* ---------- 自治体ページ /a/{id}/ ---------- */
add_action('init', function () {
    add_rewrite_rule('^a/([cwp][0-9]+)/?$', 'index.php?mz_unit=$matches[1]', 'top');
});
add_filter('query_vars', function ($v) { $v[] = 'mz_unit'; return $v; });
add_action('template_redirect', function () {
    $id = get_query_var('mz_unit');
    if ($id) {
        status_header(200);
        include get_template_directory() . '/unit.php';
        exit;
    }
});
/* テーマ有効化時の初期設定（パーマリンク・固定ページ・データ受信トークン） */
add_action('after_switch_theme', function () {
    if (!get_option('permalink_structure')) update_option('permalink_structure', '/%postname%/');
    update_option('blogdescription', 'あなたの街の「掘り起こされていない票」を見える化');
    if (!get_option('mz_push_token')) update_option('mz_push_token', bin2hex(random_bytes(24)));
    $pages = [
        ['title' => '無料会員登録', 'slug' => 'register', 'tpl' => 'page-register.php'],
        ['title' => 'プライバシーポリシー', 'slug' => 'privacy', 'tpl' => ''],
        ['title' => '特定商取引法に基づく表記', 'slug' => 'tokushoho', 'tpl' => ''],
    ];
    foreach ($pages as $p) {
        if (!get_page_by_path($p['slug'])) {
            $pid = wp_insert_post(['post_title' => $p['title'], 'post_name' => $p['slug'],
                'post_type' => 'page', 'post_status' => 'publish', 'post_content' => $p['tpl'] ? '' : '準備中です。']);
            if ($p['tpl'] && !is_wp_error($pid)) update_post_meta($pid, '_wp_page_template', $p['tpl']);
        }
    }
    wp_mkdir_p(mz_data_dir() . 'units');
    mz_data_url_protect();
    flush_rewrite_rules(true);
});
/* データ受信トークンを管理者にだけ表示（データ投入設定用） */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    $t = get_option('mz_push_token');
    $has = file_exists(mz_data_dir() . 'index.json');
    if ($t && !$has) {
        echo '<div class="notice notice-info"><p><b>埋蔵票マップ データ受信トークン:</b> <code id="mz-token">' . esc_html($t) . '</code>（分析データ投入時に使用します。データ投入後この表示は消えます）</p></div>';
    }
});

/* ---------- 会員 ---------- */
function mz_user_unit($user_id = 0) {
    $user_id = $user_id ?: get_current_user_id();
    return $user_id ? get_user_meta($user_id, 'mz_unit', true) : '';
}
function mz_can_view($id) {
    return is_user_logged_in() && (mz_user_unit() === $id || current_user_can('manage_options'));
}

/* 登録フォーム処理（page-register.php から） */
function mz_handle_register() {
    if (!isset($_POST['mz_reg_nonce']) || !wp_verify_nonce($_POST['mz_reg_nonce'], 'mz_register')) return null;
    $name  = sanitize_text_field($_POST['mz_name'] ?? '');
    $addr  = sanitize_text_field($_POST['mz_address'] ?? '');
    $mail  = sanitize_email($_POST['mz_email'] ?? '');
    $tel   = sanitize_text_field($_POST['mz_phone'] ?? '');
    $unit  = sanitize_text_field($_POST['mz_unit'] ?? '');
    if (!$name || !$addr || !$mail || !$tel || !$unit) return ['err' => '未入力の項目があります。すべての項目をご入力ください。'];
    if (!is_email($mail)) return ['err' => 'メールアドレスの形式が正しくありません。'];
    if (!mz_unit($unit)) return ['err' => '自治体の選択が正しくありません。候補から選択してください。'];
    if (email_exists($mail)) return ['err' => 'このメールアドレスは登録済みです。ログインするか、パスワード再設定をご利用ください。'];
    $uid = wp_insert_user([
        'user_login'   => $mail,
        'user_email'   => $mail,
        'user_pass'    => wp_generate_password(24), // 仮。本人がメールのリンクで設定し直す
        'display_name' => $name,
        'role'         => 'subscriber',
    ]);
    if (is_wp_error($uid)) return ['err' => '登録に失敗しました: ' . esc_html($uid->get_error_message())];
    update_user_meta($uid, 'mz_name', $name);
    update_user_meta($uid, 'mz_address', $addr);
    update_user_meta($uid, 'mz_phone', $tel);
    update_user_meta($uid, 'mz_unit', $unit);
    wp_new_user_notification($uid, null, 'both'); // 本人にパスワード設定リンク＋管理者に通知
    return ['ok' => true, 'unit' => $unit];
}

/* 管理画面: 会員一覧に登録情報列を表示 */
add_filter('manage_users_columns', function ($c) {
    $c['mz_unit'] = '登録自治体'; $c['mz_phone'] = '電話'; $c['mz_address'] = '住所';
    return $c;
});
add_filter('manage_users_custom_column', function ($val, $col, $uid) {
    if ($col === 'mz_unit') {
        $u = mz_unit(get_user_meta($uid, 'mz_unit', true));
        return $u ? esc_html($u['pref'] . $u['name'] . '（' . $u['sub'] . '）') : '—';
    }
    if ($col === 'mz_phone') return esc_html(get_user_meta($uid, 'mz_phone', true));
    if ($col === 'mz_address') return esc_html(get_user_meta($uid, 'mz_address', true));
    return $val;
}, 10, 3);

/* 会員はログイン後に自分の自治体ページへ、管理者はダッシュボードへ */
add_filter('login_redirect', function ($to, $req, $user) {
    if ($user instanceof WP_User && !user_can($user, 'manage_options')) {
        $unit = mz_user_unit($user->ID);
        if ($unit) return home_url('/a/' . $unit . '/');
        return home_url('/');
    }
    return $to;
}, 10, 3);
/* 一般会員には管理バーを出さない */
add_filter('show_admin_bar', function ($show) {
    return current_user_can('manage_options') ? $show : false;
});

/* ---------- 週次データ更新 REST（GitHub Actions 用） ---------- */
add_action('rest_api_init', function () {
    register_rest_route('maizouhyo/v1', '/push', [
        'methods'  => 'POST',
        'permission_callback' => function ($req) {
            $t = get_option('mz_push_token');
            return $t && hash_equals($t, (string)$req->get_header('x-mz-token'));
        },
        'callback' => function ($req) {
            $p = $req->get_json_params();
            /* 単発 {file,json} または一括 {files:[{file,json},...]} */
            $items = isset($p['files']) && is_array($p['files']) ? $p['files']
                   : ((!empty($p['file']) && isset($p['json'])) ? [$p] : null);
            if ($items === null) return new WP_Error('bad_request', 'file/json or files[] required', ['status' => 400]);
            $dir = mz_data_dir();
            wp_mkdir_p($dir . 'units');
            mz_data_url_protect();
            $saved = 0; $bad = [];
            foreach ($items as $it) {
                $file = $it['file'] ?? '';
                if (!preg_match('#^(index\.json|units/[cwp]\d{1,7}\.json)$#', $file) || !isset($it['json'])) { $bad[] = $file; continue; }
                if (file_put_contents($dir . $file, wp_json_encode($it['json'], JSON_UNESCAPED_UNICODE))) $saved++;
            }
            return ['saved' => $saved, 'bad' => $bad];
        },
    ]);
});
