<?php
/* 自治体ページ /a/{id}/ — 未登録: ランク+基本情報+ぼかし / 会員(当該自治体): 分析レポート */
$id = get_query_var('mz_unit');
$u  = mz_unit($id);
if (!$u) { global $wp_query; $wp_query->set_404(); status_header(404); get_header(); echo '<div class="wrap" style="padding:80px 20px"><h1>ページが見つかりません</h1></div>'; get_footer(); exit; }
$member = mz_can_view($id);
$rankmap = ['S' => 5, 'A' => 4, 'B' => 3, 'C' => 2, 'D' => 1];
$ron = $rankmap[$u['rank']] ?? 0;
$rank_text = ['S' => '全国最上位', 'A' => '全国上位', 'B' => '全国平均圏', 'C' => 'やや少なめ', 'D' => '少なめ'][$u['rank']] ?? '';
$fmt = function ($v) { return $v === null || $v === '' ? '—' : number_format(round((float)$v)); };
$dt = $u['date'] ? date_i18n('Y年n月j日', strtotime($u['date'])) : '—';
$is_muhyo = !empty($u['muhyo']);
get_header(); ?>

<div class="pagehead">
  <div class="wrap">
    <div class="crumbs">埋蔵票マップ ＞ <?php echo esc_html($u['pref']); ?> ＞ <?php echo esc_html($u['name']); ?></div>
    <h1><small><?php echo esc_html($u['pref']); ?></small><?php echo esc_html($u['name']); ?> <span style="font-size:.55em;font-weight:700;color:#9fb2d4"><?php echo esc_html($u['sub']); ?>の分析</span></h1>
    <div class="meta">
      <span>📅 前回選挙：<?php echo esc_html($dt); ?></span>
      <?php if ($u['seats']) : ?><span>🪑 定数：<?php echo esc_html($u['seats']); ?></span><?php endif; ?>
      <?php if ($u['n_cands']) : ?><span>🗳 前回候補者数：<?php echo esc_html($u['n_cands']); ?>人</span><?php endif; ?>
      <?php if ($u['next']) : ?><span>🔄 次回想定：<?php echo esc_html($u['next']); ?></span><?php endif; ?>
    </div>
  </div>
</div>

<main class="unit-main">
  <div class="wrap">

  <?php if (!empty($u['muhyo_note'])) : ?>
    <div class="notice" style="margin-top:22px">※ <?php echo esc_html($u['muhyo_note']); ?></div>
  <?php endif; ?>

  <?php if ($member) : /* ================= 会員：分析レポート ================= */ ?>

    <div class="report-bar" style="margin-top:22px">
      <span class="who">👤 <?php echo esc_html(wp_get_current_user()->display_name); ?> 様の登録自治体</span>
      <button class="btn btn-cta no-print" onclick="window.print()">📄 PDFとして保存・印刷</button>
    </div>

    <div class="report">
      <div class="rp-head">
        <div class="t"><small>MAIZOHYO ANALYSIS REPORT</small><b><?php echo esc_html($u['pref'] . ' ' . $u['name']); ?>｜<?php echo esc_html($u['sub']); ?> 分析レポート</b></div>
        <div class="lg">発行<b>埋蔵票マップ</b><?php echo esc_html(date_i18n('Y年n月j日')); ?>時点</div>
      </div>

      <h3>1. サマリー</h3>
      <div class="tiles">
        <div class="tile gold"><span>⛏ 埋蔵票（推計）</span><b><?php echo $fmt($u['fl']); ?><small>票</small></b></div>
        <div class="tile"><span>🏁 前回の当選ライン</span><b><?php echo $fmt($u['line']); ?><small>票</small></b></div>
        <div class="tile"><span>🎯 無所属新人の必要票</span><b><?php echo $fmt($u['need']); ?><small>票</small></b></div>
        <div class="tile"><span>👥 現職の予測合計<?php echo $u['ind_incumbents'] ? '（個人系' . (int)$u['ind_incumbents'] . '人）' : ''; ?></span><b><?php echo $fmt($u['ind_pred']); ?><small>票</small></b></div>
      </div>
      <?php if ($u['fl'] !== null && $u['line']) : $bai = $u['line'] > 0 ? round($u['fl'] / $u['line'], 1) : null; ?>
      <p style="font-size:13.5px;color:var(--ink-2);margin-top:14px">前回の有効投票総数は <b><?php echo $fmt($u['total_valid']); ?>票</b>。うち約 <b><?php echo $fmt($u['fl']); ?>票</b> が、既存の政党・現職のいずれにも固定されていない「埋蔵票」と推計されます。<?php if ($bai !== null && $bai > 0) : ?>これは当選ライン（<?php echo $fmt($u['line']); ?>票）の約<?php echo esc_html($bai); ?>人分に相当します。<?php endif; ?></p>
      <?php endif; ?>

      <?php if (!empty($u['parties'])) : ?>
      <h3>2. 政党別の期待票と上積み余地</h3>
      <div class="tblwrap">
      <table class="mz">
        <thead><tr><th>政党</th><th>期待票</th><th>現職の予測</th><th>上積み余地</th><th>公認新人の不足票</th></tr></thead>
        <tbody>
        <?php foreach ($u['parties'] as $p) : ?>
          <tr>
            <td><?php echo esc_html($p['p']); ?></td>
            <td><?php echo number_format($p['pool']); ?></td>
            <td><?php echo $p['inc_n'] ? number_format($p['inc_pred']) . '（' . (int)$p['inc_n'] . '人）' : '—（現職なし）'; ?></td>
            <td class="<?php echo $p['surplus'] > 0 ? 'pos' : ''; ?>"><?php echo $p['surplus'] > 0 ? '+' . number_format($p['surplus']) : '0'; ?></td>
            <td class="<?php echo $p['shortfall'] > 0 ? 'neg' : 'pos'; ?>"><?php echo $p['shortfall'] > 0 ? number_format($p['shortfall']) : '0（ライン到達）'; ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <p class="inc-note">※ 期待票は直近の国政選挙の比例得票等から推計した、その政党がこの選挙で見込める票の目安です。</p>
      <?php endif; ?>

      <?php if (!empty($u['incumbents'])) : ?>
      <h3>3. 現職の得票と次回予測</h3>
      <div class="tblwrap">
      <table class="mz">
        <thead><tr><th>候補者</th><th>所属</th><th>当選回数</th><th>前回得票</th><th>次回予測</th></tr></thead>
        <tbody>
        <?php foreach ($u['incumbents'] as $c) : ?>
          <tr>
            <td><?php echo esc_html($c['name'] ?: '（氏名非公開）'); ?></td>
            <td style="text-align:left"><?php echo esc_html($c['party'] ?: '無所属'); ?></td>
            <td><?php echo $c['wins'] ? (int)$c['wins'] . '回' : '—'; ?></td>
            <td><?php echo $fmt($c['votes']); ?></td>
            <td><?php echo $fmt($c['pred']); ?></td>
          </tr>
        <?php endforeach; ?>
          <?php if ($u['line']) : ?><tr class="winline"><td colspan="5">─── 前回の当選ライン <?php echo $fmt($u['line']); ?>票 ───</td></tr><?php endif; ?>
        <?php if (!empty($u['losers'])) : foreach ($u['losers'] as $c) : ?>
          <tr class="loser">
            <td><?php echo esc_html($c['name'] ?: '（氏名非公開）'); ?></td>
            <td style="text-align:left"><?php echo esc_html($c['party'] ?: '無所属'); ?></td>
            <td>—</td>
            <td><?php echo $fmt($c['votes']); ?></td>
            <td>落選</td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
      </div>
      <?php endif; ?>

      <div class="rp-note">
        本レポートは、公開されている選挙結果および国政選挙の比例得票データをもとに、株式会社MOPPsが独自の統計モデルで推計した参考値です。実際の選挙結果を保証するものではありません。データの転載・第三者への提供はご遠慮ください。<br>
        © 株式会社MOPPs／埋蔵票マップ（analysis.mopps.co.jp）
      </div>
    </div>

  <?php else : /* ================= 未登録・他自治体の会員 ================= */ ?>

    <div class="card" style="margin-top:22px">
      <div class="rank-grid">
        <div class="rank-badge" style="background:conic-gradient(var(--gold) 0 <?php echo $ron * 20; ?>%, #e9edf5 <?php echo $ron * 20; ?>% 100%)"><b><?php echo esc_html($u['rank'] ?: '—'); ?></b></div>
        <div class="rank-desc">
          <p style="font-size:15px;margin-bottom:10px"><?php echo esc_html($u['name']); ?>の埋蔵票ランクは <b style="color:var(--navy)"><?php echo esc_html($u['rank'] ?: '—'); ?><?php echo $rank_text ? '（' . $rank_text . '）' : ''; ?></b>。<?php if ($ron >= 4) : ?>既存の政党・現職に固定されていない票が<b style="color:var(--navy)">比較的多く眠っている</b>自治体です。<?php elseif ($ron > 0) : ?>埋蔵票の規模を5段階で評価しています。<?php endif; ?></p>
          <div class="rank-scale"><?php for ($i = 1; $i <= 5; $i++) echo '<i class="' . ($i <= $ron ? 'on' : '') . '"></i>'; ?></div>
          <div class="rank-scale-l"><span>D</span><span>C</span><span>B</span><span>A</span><span>S</span></div>
          <p style="font-size:12.5px;color:var(--ink-3);margin-top:8px">※ ランクは埋蔵票の推計規模を5段階で表したものです。実数値は会員向けに公開しています。</p>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>専門分析レポート <span class="badge">🔒 会員限定</span></h2>
      <div class="locked">
        <div class="blurred">
          <div class="tiles">
            <div class="tile gold"><span>⛏ 埋蔵票（推計）</span><b>0,000<small>票</small></b></div>
            <div class="tile"><span>🏁 前回の当選ライン</span><b>0,000<small>票</small></b></div>
            <div class="tile"><span>🎯 無所属新人の必要票</span><b>0,000<small>票</small></b></div>
            <div class="tile"><span>👥 現職の予測合計</span><b>00,000<small>票</small></b></div>
          </div>
        </div>
        <div class="lock-overlay">
          <div class="ic">🔒</div>
          <p>この街の専門分析は無料会員に公開しています<small>出馬予定の自治体としてご登録ください（登録無料）</small></p>
          <?php if (is_user_logged_in()) : ?>
            <small style="color:var(--ink-2)">※ 現在ご登録の自治体と異なります。変更をご希望の場合は運営までご連絡ください。</small>
          <?php else : ?>
            <a class="btn btn-cta" href="<?php echo esc_url(home_url('/register/?unit=' . $id)); ?>">無料会員登録して見る</a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php if (!is_user_logged_in()) : ?>
    <div class="cta-card">
      <h2><?php echo esc_html($u['name']); ?>の専門分析を、無料で。</h2>
      <p>会員登録して「出馬予定の自治体」に<?php echo esc_html($u['name']); ?>を選ぶと、埋蔵票の実数・当選ライン・政党別分析・現職予測のレポートが見られます。</p>
      <a class="btn btn-cta" href="<?php echo esc_url(home_url('/register/?unit=' . $id)); ?>">無料会員登録する</a>
    </div>
    <?php endif; ?>

  <?php endif; ?>

  </div>
</main>

<?php get_footer(); ?>
