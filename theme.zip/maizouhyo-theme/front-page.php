<?php get_header(); ?>

<div class="hero">
  <div class="japan-map"><?php include get_template_directory() . '/japan-map.svg.php'; ?></div>
  <div class="wrap">
    <span class="kicker">選挙データ分析サービス｜全国1,741市区町村対応</span>
    <h1>あなたの街には、<br>まだ<span class="gold">掘り起こされていない票</span>がある。</h1>
    <p class="lead">埋蔵票マップは、全国の地方選挙を統計分析し、どの自治体に・どれだけの「動く票」が眠っているかを見える化するサービスです。出馬を考えるあなたの、最初の戦略資料に。</p>
    <div class="searchbox">
      <input id="mzSearch" type="text" placeholder="自治体名で検索（例：新座市、世田谷区、嵐山町）" autocomplete="off">
      <div class="hits" id="mzHits" style="display:none"></div>
    </div>
    <div class="cta-row">
      <a class="btn btn-cta" href="<?php echo esc_url(home_url('/register/')); ?>">無料で会員登録する</a>
      <a class="btn btn-w" href="#about">埋蔵票とは？</a>
    </div>
  </div>
</div>

<div class="stats">
  <div class="wrap">
    <div class="stat"><b>16<small>万件超</small></b><span>候補者・得票データ</span></div>
    <div class="stat"><b>5,500<small>回超</small></b><span>読み込んだ地方選挙</span></div>
    <div class="stat"><b>20<small>年超</small></b><span>分析対象期間</span></div>
    <div class="stat"><b>2,971<small>単位</small></b><span>市区町村・政令市区・県議選挙区</span></div>
  </div>
</div>

<section class="sec" id="about">
  <div class="wrap">
    <div class="sec-k">WHAT IS MAIZOHYO</div>
    <h2>「埋蔵票」とは、既存の政党・現職に<br>固定されていない票のこと。</h2>
    <p class="sec-lead">選挙で投じられる票のすべてが、特定の政党や現職候補に固定されているわけではありません。埋蔵票マップは、国政選挙の比例得票と過去の地方選挙結果を独自の統計モデルで分析し、次の選挙で「新しい候補者が獲得しうる票」＝埋蔵票を自治体ごとに推計します。</p>
    <div class="flow">
      <div class="step">
        <div class="ic-svg"><svg viewBox="0 0 24 24"><path d="M9 4 3.5 6.2v13.3L9 17.3l6 2.2 5.5-2.2V4L15 6.2 9 4Z"/><path d="M9 4v13.3M15 6.2v13.3"/></svg></div>
        <b>どの街に票が眠っているか</b><p>全国の市区町村・政令市の区・都道府県議選挙区ごとに埋蔵票を推計。出馬先の検討材料になります。</p>
      </div>
      <div class="step">
        <div class="ic-svg"><svg viewBox="0 0 24 24"><path d="M6 21V4"/><path d="M6 4h11l-2.5 4L17 12H6"/></svg></div>
        <b>当選に何票必要か</b><p>直近選挙の当選ラインと候補者構成から、あなたが目指すべき得票の目安がわかります。</p>
      </div>
      <div class="step">
        <div class="ic-svg"><svg viewBox="0 0 24 24"><path d="M4 19h16"/><path d="M5 15l4-5 3.5 3L19 6"/><path d="M15.5 6H19v3.5"/></svg></div>
        <b>現職の票はどう動くか</b><p>現職候補の得票がどう推移してきたかを踏まえ、次回の勢力図を見立てます。</p>
      </div>
    </div>
  </div>
</section>

<section class="sec alt" id="data">
  <div class="wrap">
    <div class="sec-k">OUR DATA</div>
    <h2>約16万件の得票データを読み込み、<br>全国の選挙を「まるごと」分析しています。</h2>
    <p class="sec-lead">埋蔵票マップの分析は、過去20年超・5,500回を超える地方選挙の候補者・得票データ約16万件と、対応する国政選挙の比例得票データに基づいています。対象は全国1,741市区町村すべて。政令指定都市は区単位、都道府県議会は1,082選挙区単位でカバーし、選挙が行われるたびに毎週自動でデータが更新されます。</p>
  </div>
</section>

<section class="sec" id="members">
  <div class="wrap">
    <div class="sec-k">MEMBERSHIP</div>
    <h2>登録は無料。あなたの街の「専門分析」が<br>見られるようになります。</h2>
    <p class="sec-lead">どなたでも全国すべての自治体の基本情報と埋蔵票ランク（S〜D）をご覧いただけます。無料会員に登録すると、あなたが出馬を予定する（または現に議員を務める）自治体について、数値の入った専門分析レポートが開放されます。</p>
    <div class="flow">
      <div class="step"><span class="tag">STEP 1</span><b>街を検索する</b><p>気になる自治体を検索。埋蔵票ランクと基本情報は登録なしで見られます。</p></div>
      <div class="step"><span class="tag">STEP 2</span><b>無料会員登録</b><p>出馬を予定する自治体（現職の方はいまの自治体）をひとつ選んで登録します。</p></div>
      <div class="step"><span class="tag">STEP 3</span><b>専門分析レポート</b><p>あなたの街の埋蔵票・当選ライン・政党別分析がすべて開放。PDF保存もできます。</p></div>
    </div>
  </div>
</section>

<section class="sec alt" id="company">
  <div class="wrap">
    <div class="sec-k">COMPANY</div>
    <h2>選挙を研究する大学院生が、<br>本気でつくった分析サービスです。</h2>
    <p class="sec-lead">埋蔵票マップを運営する株式会社MOPPsは、選挙の分析を行う京都大学公共政策大学院の社会人学生が立ち上げた会社です。「地盤・看板・カバンがなくても挑戦できる選挙」を目指し、データの力で新しい候補者の一歩を支えます。選挙運動の支援サービスについては <a href="https://senkyo.mopps.co.jp/" target="_blank" rel="noopener" style="color:var(--accent-dark);font-weight:700;border-bottom:1.5px solid var(--accent)">0円選挙.com（senkyo.mopps.co.jp）</a> をご覧ください。</p>
  </div>
</section>

<section class="sec" style="background:linear-gradient(150deg,var(--navy-deep),var(--navy));color:#fff;text-align:center">
  <div class="wrap">
    <h2 style="color:#fff">あなたの街の埋蔵票、<br>いま確かめてみませんか。</h2>
    <p style="color:#c9d4e8;max-width:620px;margin:0 auto 30px">登録は無料。出馬予定の自治体を選ぶだけで、専門分析がすべて見られます。</p>
    <a class="btn btn-cta" style="padding:15px 40px;font-size:16px" href="<?php echo esc_url(home_url('/register/')); ?>">無料で会員登録する</a>
  </div>
</section>

<script>
const MZ_UNITS = <?php echo mz_index_slim_json(); ?>;
const inp = document.getElementById('mzSearch'), hits = document.getElementById('mzHits');
const norm = s => s.normalize('NFKC');
inp.addEventListener('input', () => {
  const q = norm(inp.value.trim());
  if (q.length < 1) { hits.style.display = 'none'; return; }
  const m = MZ_UNITS.filter(u => (u[1] + u[2]).includes(q) || u[2].includes(q)).slice(0, 12);
  hits.innerHTML = m.map(u =>
    `<a href="<?php echo esc_js(home_url('/a/')); ?>${u[0]}/"><span>${u[1]} <b>${u[2]}</b> <span class="k">${u[3]}</span></span><span class="rank-pill r${u[4]}">${u[4]}</span></a>`
  ).join('') || '<a>該当なし</a>';
  hits.style.display = 'block';
});
document.addEventListener('click', e => { if (!e.target.closest('.searchbox')) hits.style.display = 'none'; });
</script>

<?php get_footer(); ?>
